# RomiPi MultiBot

This package contains materials related to multi-robotic
formations of RomiPi robots

# TODO list
* Make a node that moves forward (twist = [0.25 m/s,0 rad/s]) for 1 second
* Make a node that moves forward 10 centimeters (target position = [0.1 m, 0 m])
* Make a node that moves to a position specified by the user in RVIZ

