#!/usr/bin/python2
#

import time

class Multibot:
    def __init__(self):
        return

    def close(self):
        return

# Self Test
if __name__ == '__main__':
    print("This file does not do anything yet!")
    print("sleeping 1 second, and then quitting.")
    time.sleep(1.0)
    print("quitting now!")
