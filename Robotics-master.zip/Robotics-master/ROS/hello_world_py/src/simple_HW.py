#! /usr/bin/env python

import rospy

rospy.init_node('simple_HW_node')

print "Hello World from py"
