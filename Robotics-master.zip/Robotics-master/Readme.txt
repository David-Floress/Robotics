CPE 476 Robotics

Team Members: Jett Guerrero, David Flores, Ivan Soto 